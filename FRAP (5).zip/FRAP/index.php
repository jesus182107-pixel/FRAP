<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FRAP LH Médica - Iniciar Sesión</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="login">

    <h1>FRAP</h1>

    <h2>LH MÉDICA</h2>

    <form action="php/validar.php" method="POST">

        <input
            type="text"
            name="usuario"
            placeholder="Usuario"
            required>

        <input
            type="password"
            name="password"
            placeholder="Contraseña"
            required>

        <button type="submit">
            Ingresar
        </button>

    </form>

</div>

</body>
</html>