<?php
include("../php/conexion.php");

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die('FRAP no válido.');
}

$sql = "SELECT * FROM frap WHERE id = $id LIMIT 1";
$resultado = mysqli_query($conn, $sql);

if (!$resultado || mysqli_num_rows($resultado) === 0) {
    die('FRAP no encontrado.');
}

$fila = mysqli_fetch_assoc($resultado);

function e($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}

function mostrar($fila, $campo) {
    $valor = $fila[$campo] ?? '';
    return $valor !== '' && $valor !== null ? e($valor) : '—';
}

function bloque($titulo, $campos, $fila) {
    echo '<section class="seccion">';
    echo '<h2>' . e($titulo) . '</h2>';
    echo '<div class="grid">';

    foreach ($campos as $campo => $etiqueta) {
        echo '<div class="dato">';
        echo '<span class="etiqueta">' . e($etiqueta) . '</span>';
        echo '<div class="valor">' . mostrar($fila, $campo) . '</div>';
        echo '</div>';
    }

    echo '</div>';
    echo '</section>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FRAP <?php echo e($fila['folio']); ?></title>
<link rel="stylesheet" href="pdf.css">
</head>
<body>

<div class="barra-acciones no-print">
    <button onclick="window.print()">📄 Generar / Guardar PDF</button>
    <button class="secundario" onclick="window.close()">✕ Cerrar</button>
</div>

<main class="documento">

    <header class="encabezado">
        <div class="marca">
            <div class="logo">FRAP</div>
            <div>
                <h1>Formato de Registro de Atención Prehospitalaria</h1>
                <p>Registro digital de atención prehospitalaria</p>
            </div>
        </div>

        <div class="folio-box">
            <span>FOLIO</span>
            <strong><?php echo e($fila['folio']); ?></strong>
        </div>
    </header>

    <?php
    bloque('1. Datos del servicio', [
        'fecha' => 'Fecha',
        'hora' => 'Hora',
        'sede' => 'Sede',
        'unidad' => 'Unidad',
        'nombre_operador' => 'Operador',
        'jefe_servicio' => 'Jefe de servicio',
        'auxilires' => 'Auxiliares',
        'servicio_medico' => 'Servicio médico'
    ], $fila);

    bloque('2. Tiempos de atención', [
        'hora_llamada' => 'Hora de llamada',
        'salida_base' => 'Salida de base',
        'llegada_lugar' => 'Llegada al lugar',
        'inicio_traslado' => 'Inicio de traslado',
        'llegada_hospital' => 'Llegada a hospital',
        'salida_hospital' => 'Salida de hospital',
        'llegada_base' => 'Llegada a base'
    ], $fila);

    bloque('3. Datos del lugar y paciente', [
        'direccion_servicio' => 'Dirección del servicio',
        'municipio' => 'Municipio',
        'estado' => 'Estado',
        'nombre_paciente' => 'Nombre del paciente',
        'numero_telefono' => 'Teléfono',
        'edad' => 'Edad',
        'sexo' => 'Sexo',
        'domicilio' => 'Domicilio',
        'selecciona_motivo' => 'Motivo de atención'
    ], $fila);

    bloque('4. Antecedentes', [
        'alergias' => 'Alergias',
        'medicamentos_frecuentes' => 'Medicamentos frecuentes',
        'enfermedades_cirugias' => 'Enfermedades y cirugías',
        'eventos_previos' => 'Eventos previos',
        'ultima_comida' => 'Última comida',
        'signos_sintomas' => 'Signos y síntomas'
    ], $fila);

    bloque('5. Antecedentes obstétricos', [
        'gesta' => 'Gesta',
        'aborto' => 'Abortos',
        'partos' => 'Partos',
        'cesarias' => 'Cesáreas',
        'semanas_gestacion' => 'Semanas de gestación',
        'fecha_parto' => 'Fecha de parto',
        'contracciones' => 'Contracciones',
        'duracion' => 'Duración',
        'frecuencia' => 'Frecuencia',
        'sangrado_trasvaginal' => 'Sangrado transvaginal',
        'lugar_nacimiento' => 'Lugar de nacimiento',
        'hora_nacimiento' => 'Hora de nacimiento'
    ], $fila);

    bloque('6. Evaluación inicial', [
        'causa_urgencia' => 'Causa de urgencia',
        'mecanismo_lesion' => 'Mecanismo de lesión',
        'otras_lesiones' => 'Otras lesiones',
        'enfermedad' => 'Enfermedad',
        'estado_piel' => 'Estado de la piel',
        'via_aerea' => 'Vía aérea',
        'reflejo_deglucion' => 'Reflejo de deglución',
        'hemitorax' => 'Hemotórax',
        'sitio' => 'Sitio',
        'pulso' => 'Pulso',
        'auscultacion' => 'Auscultación',
        'respiracion' => 'Respiración',
        'nivel_conciencia' => 'Nivel de conciencia',
        'pupilas' => 'Estado de pupilas',
        'esginse' => 'ESGINSE',
        'fracturas' => 'Fracturas',
        'hemorragias' => 'Hemorragias',
        'distension_yugular' => 'Distensión yugular',
        'edema' => 'Edema'
    ], $fila);
    ?>

    <section class="seccion">
        <h2>7. Signos vitales</h2>
        <div class="tabla-wrap">
            <table class="signos">
                <thead>
                    <tr>
                        <th>Hora</th>
                        <th>FC</th>
                        <th>FR</th>
                        <th>T/A</th>
                        <th>SpO₂</th>
                        <th>Temp.</th>
                        <th>Gluc.</th>
                    </tr>
                </thead>
                <tbody>
                <?php for ($i = 1; $i <= 4; $i++): ?>
                    <tr>
                        <td><?php echo mostrar($fila, 'hora'.$i); ?></td>
                        <td><?php echo mostrar($fila, 'fc'.$i); ?></td>
                        <td><?php echo mostrar($fila, 'fr'.$i); ?></td>
                        <td><?php echo mostrar($fila, 'ta'.$i); ?></td>
                        <td><?php echo mostrar($fila, 'spo2'.$i); ?></td>
                        <td><?php echo mostrar($fila, 'temp'.$i); ?></td>
                        <td><?php echo mostrar($fila, 'gluc'.$i); ?></td>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </section>

    <?php
    bloque('8. Descripción de la escena', [
        'descripcion_ecena' => 'Descripción de la escena'
    ], $fila);

    bloque('9. Atención y procedimientos', [
        'control_cervical' => 'Control de cervicales',
        'asistencia_ventilatoria' => 'Asistencia ventilatoria',
        'liquidos_endovenosos' => 'Líquidos endovenosos',
        'soluciones_administradas' => 'Soluciones administradas',
        'control_hemorragias' => 'Control de hemorragias',
        'aspiracion_secreciones' => 'Aspiración de secreciones',
        'inmovilisacion_curaciones' => 'Inmovilización y curaciones',
        'rcp' => 'RCP',
        'terapia_electrica' => 'Terapia eléctrica',
        'suturas' => 'Sutura',
        'oxigeno' => 'Oxígeno',
        'joules' => 'Joules'
    ], $fila);

    bloque('10. Traslado y entrega', [
        'triage_llegada' => 'Triage al llegar',
        'triage_entrega' => 'Triage al entregar',
        'entrega_dorctor' => 'Entrega al doctor'
    ], $fila);
    ?>

    <footer class="pie">
        <div>FRAP DIGITAL</div>
        <div>Folio: <?php echo e($fila['folio']); ?></div>
        <div>Generado: <?php echo date('d/m/Y H:i'); ?></div>
    </footer>

</main>

<script>
window.addEventListener('load', function () {
    setTimeout(function () {
        window.print();
    }, 500);
});
</script>

</body>
</html>
