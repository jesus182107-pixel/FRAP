<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header("Location:index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<title>Dashboard</title>

<link rel="stylesheet" href="css/dashboard.css">



</head>

<body>

<div class="header">

<div>
🚑 FRAP LH MÉDICA
</div>

<div>
<?php echo $_SESSION['nombre']; ?>
</div>

</div>

<div class="sidebar">

<a href="dashboard.php">🏠 Inicio</a>

<a href="dashboard.php?modulo=nuevo_frap">📋 Nuevo FRAP</a>

<a href="#">👤 Pacientes</a>

<a href="#">🚑 Unidades</a>

<a href="dashboard.php?modulo=historial">📄 Historial</a>

<a href="#">📊 Reportes</a>

<a href="#">⚙ Configuración</a>

<a href="php/logout.php">🚪 Cerrar sesión</a>

</div>
<div class="main">

<div class="card">

<?php

if(isset($_GET['modulo'])){

    $modulo = $_GET['modulo'];

    if(file_exists("modulos/".$modulo.".php")){

        include("modulos/".$modulo.".php");

    }else{

        echo "<h2>Módulo no encontrado</h2>";

    }

}else{

    include("modulos/inicio.php");

}

?>

</div>

</div>
</div>

</div>

</body>

</html>