<?php
include("php/conexion.php");

$sql = "SELECT * FROM frap ORDER BY id DESC";
$resultado = mysqli_query($conn, $sql);
?>

<div class="contenedor-historial">

    <h2>📋 Historial de FRAP</h2>

    <div class="busqueda">

        <input
            type="text"
            id="buscar"
            placeholder="Buscar por folio, paciente, unidad..."
            onkeyup="buscarTabla()">

    </div>

    <table id="tablaHistorial">

        <thead>

            <tr>

                <th>ID</th>
                <th>Folio</th>
                <th>Fecha</th>
                <th>Paciente</th>
                <th>Unidad</th>
                <th>Operador</th>
                <th>Acciones</th>

            </tr>

        </thead>

        <tbody>

        <?php while($fila=mysqli_fetch_assoc($resultado)){ ?>

            <tr>

                <td><?php echo $fila['id']; ?></td>

                <td><?php echo $fila['folio']; ?></td>

                <td><?php echo $fila['fecha']; ?></td>

                <td><?php echo $fila['nombre_paciente']; ?></td>

                <td><?php echo $fila['unidad']; ?></td>

                <td><?php echo $fila['nombre_operador']; ?></td>

                <td>

                    <a href="dashboard.php?modulo=ver_frap&id=<?php echo $fila['id']; ?>" class="btn-ver">👁</a>

                    <a href="modulos/editar_frap.php?id=<?php echo $fila['id']; ?>" class="btn-editar">✏</a>

                    <a href="php/eliminar_frap.php?id=<?php echo $fila['id']; ?>"
                    onclick="return confirm('⚠️ ¿Estás seguro de eliminar el FRAP con folio: <?php echo $fila['folio']; ?>?\n\nEsta acción no se puede deshacer.')"
                    class="btn-eliminar">🗑</a>

                    <a href="pdf/generar_pdf.php?id=<?php echo $fila['id']; ?>" class="btn-pdf">📄</a>

                </td>

            </tr>

        <?php } ?>

        </tbody>

    </table>

</div>

<script>

function buscarTabla(){

    let input=document.getElementById("buscar");

    let filtro=input.value.toUpperCase();

    let tabla=document.getElementById("tablaHistorial");

    let tr=tabla.getElementsByTagName("tr");

    for(let i=1;i<tr.length;i++){

        let texto=tr[i].textContent.toUpperCase();

        if(texto.indexOf(filtro)>-1){

            tr[i].style.display="";

        }else{

            tr[i].style.display="none";

        }

    }

}

</script>