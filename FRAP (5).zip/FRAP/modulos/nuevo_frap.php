<?php

// Generar folio automático temporal
$anio = date("Y");
$folio = "FRAP-" . $anio . "-000001";

?>

<h1>📋 Nuevo FRAP</h1>

<hr>


<form class="frap-form" action="php/guardar_frap.php" method="POST">

<div class="form-grid">



    <div class="form-group col-4">
        <label>Folio</label>
        <input type="text" id="folio" name="folio" value="<?php echo $folio; ?>" readonly>
    </div>


    <div class="form-group col-4">
        <label>Fecha</label>
        <input type="date" name="fecha" id="fecha" value="<?php echo date('Y-m-d'); ?>" readonly>
    </div>

    <div class="form-group col-4">
        <label>Hora</label>
        <input type="time" name="hora" id="hora" value="<?php echo date('H:i'); ?>" readonly>
    </div>

    <div class="form-group col-4">
        <label>Sede</label>
        <input type="text" name="sede" id="sede" placeholder="Ingrese sede">
    </div>

    <div class="form-group col-4">
        <label>Unidad</label>
        <select id="unidad" name="unidad">
            <option>Seleccione</option>
            <option>A-01</option>
            <option>A-02</option>
        </select>
    </div>

<h1 class="form-group col-12">Datos de la Tripulacion</h1>
<hr class="form-group col-12">



    <div class="form-group col-4">
        <label>Nombre del Operador</label>
        <input type="text" id="nombre_operador" name="nombre_operador">
    </div>

    <div class="form-group col-4">
        <label>Jefe de Servicio</label>
        <input type="text" id="jefe_servicio" name="jefe_servicio"  value="LIC ENF / TEM-A Luis Enrique Hernandez Gaytan.">
    </div>

    <div class="form-group col-4">
        <label>Auxiliares</label>
        <input type="text" id="auxiliares" name="auxilires">
    </div>

    <div class="form-group col-2">
        <label>Hora de Llamada</label>
        <input type="time" id="hora_llamada" name="hora_llamada">
    </div>
    <div class="form-group col-2">
        <label>Salida de base</label>
        <input type="time" id="salida_base" name="salida_base">
    </div>
    <div class="form-group col-2">
        <label>Llegada al lugar</label>
        <input type="time" id="llegada_lugar" name="llegada_lugar">
    </div>
    <div class="form-group col-2">
        <label>Inicio traslado</label>
        <input type="time" id="inicio_traslado" name="inicio_traslado">
    </div>
    <div class="form-group col-2">
        <label>Llegada Hospital</label>
        <input type="time" id="llegada_hospital" name="llegada_hospital">
    </div>
    <div class="form-group col-2">
        <label>Salida Hospital</label>
        <input type="time" id="salida_hospital" name="salida_hospital">
    </div>
    <div class="form-group col-2">
        <label>Llegada a Base</label>
        <input type="time" id="llegada_base" name="llegada_base">
    </div>

    
<h1 class="form-group col-12">Datos de Servicio</h1>
<hr class="form-group col-12">

    <div class="form-group col-6">
        <label>Direccion de Servicio</label>
        <input type="text" id="direccion_servicio" name="direccion_servicio">
    </div>
     <div class="form-group col-6">
        <label>Municipio</label>
        <input type="text" id="municipio" name="municipio">
    </div>
     <div class="form-group col-6">
        <label>Estado</label>
        <input type="text" id="estado" name="estado">
    </div>
    <h1 class="form-group col-12">Datos del Paciente</h1>
    <hr class="form-group col-12">

    <div class="form-group col-4">
        <label>Nombre del Paciente</label>
        <input type="text" id="nombre_paciente" name="nombre_paciente">
    </div>
    <div class="form-group col-3">
        <label>Numero de Telefono</label>
        <input type="text" id="numero_telefono" name="numero_telefono">
    </div>
    <div class="form-group col-3">
        <label>Edad</label>
        <input id="edad" name="edad" type="number"min="0"max="120">
    </div>

    <div class="form-group col-4">
        <label>Sexo</label>
        <select id="sexo" name="sexo">
            <option>Seleccione</option>
            <option>MASCULINO</option>
            <option>FEMENINO</option>
            <option>OTRO</option>
        </select>
    </div>

    <div class="form-group col-6">
        <label>Domicilio</label>
        <input type="text" id="domicilio" name="domicilio">
    </div>

    <div class="form-group col-4">
        <label>Servicio Médico</label>
        <select id="servicio_medico" name="servicio_medico">
            <option>Seleccione</option>
            <option>IMSS</option>
            <option>ISSSTE</option>
            <option>CRUZ ROJA</option>
            <option>BIENESTAR</option>
            <option>FOVISSSTE</option>
        </select>
    </div>
    <h1 class="form-group col-12">Motivo Solicitud de Servicio</h1>
    <hr class="form-group col-12">

    <div class="form-group col-4">
        <label>Seleciona Motivo</label>
        <select id="selecciona_motivo" name="selecciona_motivo">
            <option>Accidente Industrial o En Oficina</option>
            <option>Accidente Vehicular</option>
            <option>Alergia/ Picadura De Animal</option>
            <option>Accidente Vehicular</option>
            <option>Apoyo a Ambulancia Terrestre</option>
            <option>Apoyo En Incendio</option>
            <option>Apoyo En Sismo</option>
            <option>Asfixia/ Ahogamiento</option>
            <option>Asfixia/ Ahogamiento</option>
            <option>Complicacion Diabetica</option>
            <option>Complicación Gineco-obstetrica</option>
            <option>Complicacion Respiratoria</option>
            <option>Convulsiones</option>
            <option>Electrocucion</option>
            <option>Evento Vascular Cerebral</option>
            <option>Exposición a Calor/ Frio</option>
            <option>Hemorragia</option>
            <option>Intoxicación</option>
            <option>Lesion Por Arma Blanca</option>
            <option>Lesion Por Arma De Fuego</option>
            <option>Mordedura De Animal</option>
            <option>Atropellado</option>
            <option>Apoyo a Ambulancia Aerea</option>
            <option>Caida</option>
            <option>Cobertura De Evento</option>
            <option>Dolor Intenso </option>
            <option>Dolor Toracico/ Cardiovascular</option>
            <option>Inhalacion De Gases Peligrosos </option>
            <option>Intento/Amenaza De Suicidio</option>
            <option>Parto</option>
            <option>Perdida De La Consciencia</option>
            <option>Persona Enferma </option>
            <option>Problema De La Conducta</option>
            <option>Quemaduras</option>
            <option>Sangrado/ Laceracion</option>
            <option>sincope/ Lipotimia</option>
            <option>Sobredosis De Fármacos</option>
            <option>Traslado Foraneo</option>
            <option>Traslado Local</option>
            <option>Fractura</option>
            <option>Traslado De Terapia Intensiva</option>
            <option>Traslado De Urgencia Avanzada</option>            
        </select>
    </div>
    

    <h1 class="form-group col-12">Antecedentes Patologicos</h1>
    <hr class="form-group col-12">

    <div class="form-group col-8">
        <label>Signos y Sintomas</label>
        <input type="text" id="signos_sintomas" name="signos_sintomas">
    </div>
    <div class="form-group col-4">
        <label>Alergias</label>
        <input type="text" id="alergias" name="alergias">
    </div>
    <div class="form-group col-6">
        <label>Medicamentos Frecuentes</label>
        <input type="text" id="medicamentos_frecuentes" name="medicamentos_frecuentes">
    </div>
    <div class="form-group col-6">
        <label>Enfermedades y Cirugias Previas</label>
        <input type="text" id="enfermedades_cirugias" name="enfermedades_cirugias">
    </div>
    <div class="form-group col-6">
        <label>Eventos Previos</label>
        <input type="text" id="eventos_previos" name="eventos_previos">
    </div>
    <div class="form-group col-6">
        <label>Ultima comida</label>
        <input type="text" id="ultima_comida" name="ultima_comida">
    </div>

    <h1 class="form-group col-12">Gineco-Obstetrico</h1>
    <hr class="form-group col-12">

    <div class="form-group col-2">
        <label>Gesta</label>
        <input type="text" id="gesta" name="gesta">
    </div>
    <div class="form-group col-2">
        <label>Abortos</label>
        <input type="text"  id="aborto" name="aborto">
    </div>
    <div class="form-group col-2">
        <label>Partos</label>
        <input type="text" id="partos" name="partos">
    </div>
    <div class="form-group col-2">
        <label>Cesarias</label>
        <input type="text" id="cesarias" name="cesarias">
    </div>
    <div class="form-group col-4">
        <label>Semanas de Gestacion</label>
        <input type="text" id="semanas_gestacion" name="semanas_gestacion">
    </div>
    <div class="form-group col-4">
        <label>Fecha Probable de Parto</label>
        <input type="date" id="fecha_parto" name="fecha_parto">
    </div>

    <div class="form-group col-4">
        <label>Contracciones</label>
        <select id="contracciones" name="contracciones">
            <option>Seleccione</option>
            <option>SI</option>
            <option>NO</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Duracion</label>
        <input type="text" id="duracion" name="duracion">
    </div>
    <div class="form-group col-3">
        <label>Frecuencia</label>
        <input type="text" id="frecuencia" name="frecuencia">
    </div>

    <div class="form-group col-3">
        <label>Sangrado trasvaginal</label>
        <select id="sangrado_trasvaginal" name="sangrado_trasvaginal">
            <option>Seleccione</option>
            <option>PRESENTE</option>
            <option>AUSENTE</option>
        </select>
    </div>
    <div class="form-group col-4">
        <label>Lugar de nacimiento</label>
        <input type="text"  id="lugar_nacimiento" name="lugar_nacimiento">
    </div>
    <div class="form-group col-4">
        <label>Hora de nacimiento</label>
        <input type="time" id="hora_nacimiento" name="hora_nacimiento">
    </div>
    <h1 class="form-group col-12">Padecimiento Actual</h1>
    <hr class="form-group col-12">

    <div class="form-group col-3">
        <label>Causa de la Urgencia</label>
        <select id="causa_urgencia" name="causa_urgencia">
            <option>Seleccione</option>
            <option>Traumatica</option>
            <option>No Traumatica</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Posible Mecanismo De Lesion:</label>
        <select id="mecanismo_lesion" name="mecanismo_lesion">
            <option>Seleccione</option>
            <option>Accidente Vehicular</option>
            <option>Lesion Penetrante</option>
            <option>Atropellamiento</option>
            <option>Lesion Por Explosion</option>
            <option>Caida</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Otras Lesiones</label>
        <select id="otras_lesiones" name="otras_lesiones">
            <option>Seleccione</option>
            <option>Quemaduras</option>
            <option>Itoxicaciones</option>
            <option>Picadura</option>
            <option>Mordeduras</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Enfermedad</label>
        <select id="enfermedad" name="enfermedad">
            <option>Seleccione</option>
            <option>Subita</option>
            <option>Cronita</option>
            <option>Complicacion</option>
        </select>
    </div>
    <h1 class="form-group col-12">Exploracion Fisica</h1>
    <hr class="form-group col-12">

    <div class="form-group col-4">
        <label>Estado Piel</label>
        <select id="estado_piel" name="estado_piel">
            <option>Seleccione</option>
            <option>Normal</option>
            <option>Palida</option>
            <option>Cianotica</option>
            <option>Diaforetica</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Via Aerea</label>
        <select id="via_aerea" name="via_aerea">
            <option>Seleccione</option>
            <option>Comprometida</option>
            <option>Permeable</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Reflejo de Deglucion</label>
        <select id="reflejo_deglucion" name="reflejo_deglucion">
            <option>Seleccione</option>
            <option>Presente</option>
            <option>Ausente</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Hemitorax</label>
        <select id="hemitorax" name="hemitorax">
            <option>Seleccione</option>
            <option>Derecho</option>
            <option>Izquierdo</option>

        </select>
    </div>
    <div class="form-group col-3">
        <label>Sitio</label>
        <select id="sitio" name="sitio">
            <option>Seleccione</option>
            <option>Apical</option>
            <option>Base</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Pulso</label>
        <select id="pulso" name="pulso">
            <option>Seleccione</option>
            <option>Rapido</option>
            <option>Lento</option>
            <option>Normal</option>
            <option>Ritmico</option>
            <option>Arritmico</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Auscultacion</label>
        <select id="auscultacion" name="auscultacion">
            <option>Seleccione</option>
            <option>Ruidos Normales</option>
            <option>Ruidos Anormales</option>
            <option>Ausentes</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Respiracion</label>
        <select id="respiracion" name="respiracion">
            <option>Seleccione</option>
            <option>Automatismo Regular</option>
            <option>Automatismo Irregular</option>
            <option>Ventilación Rápida</option>
            <option>Ventilación Superficial</option>
            <option>Apnea</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Nivel de Conciencia</label>
        <select id="nivel_conciencia" name="nivel_conciencia">
            <option>Seleccione</option>
            <option>Consciente </option>
            <option>Respuesta Al Estimulo Verbal</option>
            <option>Respuesta Al Estimulo Doloroso</option>
            <option>Inconsciente</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Fracturas</label>
        <select id="fracturas"  name="fracturas">
            <option>Seleccione</option>
            <option>Cerrada</option>
            <option>Expuesta</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Hemorragias</label>
        <select id="hemorragias" name="hemorragias">
            <option>Seleccione</option>
            <option>Capilar</option>
            <option>Arterial</option>
            <option>Venosa</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Distension Yugular Venosa</label>
        <select id="distension_yugular" name="distension_yugular">
            <option>Seleccione</option>
            <option>Presente</option>
            <option>Ausente</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Edema De Extremidades</label>
        <select id="edema" name="edema">
            <option>Seleccione</option>
            <option>Godete Grado I</option>
            <option>Godete Grado II</option>
            <option>Godete Grado III</option>
            <option>Godete Grado IV</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Esguinse</label>
        <select id="esginse" name="esginse">
            <option>Seleccione</option>
            <option>Grado I</option>
            <option>Grado II</option>
            <option>Grado III</option>
        </select>
    </div>
    <div class="form-group col-3">
        <label>Pupilas</label>
        <select id="pupilas" name="pupilas">
            <option>Seleccione</option>
            <option>Isocoricas</option>
            <option>Midriatricas</option>
            <option>Anisocoricas</option>
            <option>Mioticas</option>
        </select>
    </div>

    <div class="form-group col-12">
        <table class="tabla-signos">

        <thead>
            <tr>
                <th>HORA</th>
                <th>FC</th>
                <th>FR</th>
                <th>T/A</th>
                <th>SPO₂</th>
                <th>TEMP</th>
                <th>GLUC</th>
            </tr>
        </thead>

        <tbody>

            <tr>
                <td><input type="time" name="hora1"></td>
                <td><input type="number" name="fc1"></td>
                <td><input type="number" name="fr1"></td>
                <td><input type="text" name="ta1"></td>
                <td><input type="number" name="spo21"></td>
                <td><input type="number" step="0.1" name="temp1"></td>
                <td><input type="number" name="gluc1"></td>
            </tr>

            <tr>
                <td><input type="time" name="hora2"></td>
                <td><input type="number" name="fc2"></td>
                <td><input type="number" name="fr2"></td>
                <td><input type="text" name="ta2"></td>
                <td><input type="number" name="spo22"></td>
                <td><input type="number" step="0.1" name="temp2"></td>
                <td><input type="number" name="gluc2"></td>
            </tr>

            <tr>
                <td><input type="time" name="hora3"></td>
                <td><input type="number" name="fc3"></td>
                <td><input type="number" name="fr3"></td>
                <td><input type="text" name="ta3"></td>
                <td><input type="number" name="spo23"></td>
                <td><input type="number" step="0.1" name="temp3"></td>
                <td><input type="number" name="gluc3"></td>
            </tr>

            <tr>
                <td><input type="time" name="hora4"></td>
                <td><input type="number" name="fc4"></td>
                <td><input type="number" name="fr4"></td>
                <td><input type="text" name="ta4"></td>
                <td><input type="number" name="spo24"></td>
                <td><input type="number" step="0.1" name="temp4"></td>
                <td><input type="number" name="gluc4"></td>
            </tr>

        </tbody>

    </table>
    </div>
    <h1 class="form-group col-12">Prioridad Y Descripcion de la Lesion</h1>
    <hr class="form-group col-12">

    <div class="form-group col-12">

    <label>Descripción de la escena</label>

    <textarea
        id="descripcion_ecena" name="descripcion_ecena"
        name="descripcion"
        rows="5"
        placeholder="Escriba los detalles de las lasiones..."></textarea>

</div>

    <h1 class="form-group col-12">Manejo Proporcionado</h1>
    <hr class="form-group col-12">

    <div class="form-group col-3">
        <label>Control Cervical</label>
        <select id="control_cervical" name="control_cervical">
            <option>Seleccione</option>
            <option>Manual</option>
            <option>Collarin Rigido</option>
            <option>Collarin blando</option>
        </select>
    </div>

    <div class="form-group col-3">
        <label>Asistencia Ventilatoria</label>
        <select id="asistencia_ventilatoria" name="asistencia_ventilatoria">
            <option>Seleccione</option>
            <option>Bolsa valvula mascarilla</option>
            <option>Ventilacion mecanica no invasiva</option>
            <option>Ventilacion mecanica Invasiva</option>
        </select>
    </div>
    <div class="form-group col-4">
        <label>Liquidos endovenosos</label>
        <input type="text" id="liquidos_endovenosos" name="liquidos_endovenosos"  placeholder="Menciona numero de cateter y cuantas vias">
    </div>
    <div class="form-group col-4">
        <label>Soluciones administradas</label>
        <input type="text" id="soluciones_administradas" name="soluciones_administradas" placeholder="Menciona tipo de solucion y cuantos mililitros">
    </div>

    <div class="form-group col-3">
        <label>Control de Hemorragias</label>
        <select id="control_hemorragias" name="control_hemorragias">
            <option>Seleccione</option>
            <option>Presion Directa </option>
            <option>Vendaje</option>
            <option>Torniquete</option>
        </select>
    </div>

   
    
    
    <div class="form-group col-4">
        <label>Aspiracion de Secreciones</label>
        <select id="aspiracion_secreciones" name="aspiracion_secreciones">
            <option>Seleccione</option>
            <option>Sonda</option>
            <option>Canula Yankauer</option>
            <option>Ducanto</option>
        </select>
    </div>
    <div class="form-group col-4">
        <label>Inmovilizacion y Curaciones</label>
        <select id="inmovilisacion_curaciones" name="inmovilisacion_curaciones">
            <option>Seleccione</option>
            <option>Inmovilizacion de Extremidades</option>
            <option>Empaquetado</option>
            <option>Curacion</option>
            <option>Vendaje</option>
            <option>Sutura</option>
        </select>
    </div>
     <div class="form-group col-4">
        <label>Reanimacion RCP</label>
        <select id="rcp" name="rcp">
            <option>Seleccione</option>
            <option>Basica</option>
            <option>Avanzada</option>
            <option>Familia se Niega</option>
        </select>
    </div>
   
    <div class="form-group col-4">
        <label>Terapia Electrica</label>
        <select id="terapia_electrica" name="terapia_electrica">
            <option>Seleccione</option>
            <option>Desfribilacion</option>
            <option>Cardio version</option>
            <option>Marca pasos</option>
        </select>
    </div>
    <div class="form-group col-4">
        <label>Sobre las suturas</label>
        <input type="text" id="suturas" name="suturas" placeholder="Menciona cantidad de puntos y tipo de sutura">
    </div>
    <div class="form-group col-4">
        <label>Oxigenoterapia</label>
        <input type="text" id="oxigeno" name="oxigeno" placeholder="Menciona dispositivo y cuantos litros">
    </div>
    <div class="form-group col-4">
        <label>Joules de descarga</label>
        <input type="text" id="joules" name="joules" placeholder="Menciona caunto y si es bifasica o monofasica">
    </div>

    <h1 class="form-group col-12">Atencion medica en el lugar y traslado</h1>
    <hr class="form-group col-12">

    <div class="form-group col-4">
        <label>Triage de llegada de ambulancia</label>
        <input type="text" id="triage_llegada" name="triage_llegada" placeholder="Menciona estado(amarillo,rojo,verde,negro)">
    </div>
    <div class="form-group col-4">
        <label>Triage de entrega a hospital receptor</label>
        <input type="text" id="triage_entrega" name="triage_entrega" placeholder="Menciona estado(amarillo,rojo,verde,negro)">
    </div>
    <div class="form-group col-4">
        <label>Hospital y Doctor Receptor</label>
        <input type="text" id="entrega_doctor" name="entrega_dorctor"   placeholder="">
    </div>
</div>
<!-- =========================================================
     FIRMAS DEL FRAP
     ========================================================= -->

<div class="firma-seccion">

    <h3>Firmas</h3>

    <div class="firmas-grid">

        <!-- FIRMA DEL OPERADOR -->
        <div class="firma-contenedor">

            <label for="firmaOperadorCanvas">
                Firma del operador
            </label>

            <div class="canvas-wrapper">
                <canvas
                    id="firmaOperadorCanvas"
                    class="firma-canvas"
                    width="600"
                    height="200">
                </canvas>
            </div>

            <input
                type="hidden"
                name="firma_operador"
                id="firmaOperador">

            <button
                type="button"
                class="btn-limpiar-firma"
                onclick="limpiarFirma('operador')">
                Limpiar firma
            </button>

        </div>


        <!-- FIRMA DEL PACIENTE / FAMILIAR -->
        <div class="firma-contenedor">

            <label for="firmaPacienteCanvas">
                Firma del paciente / familiar
            </label>

            <div class="canvas-wrapper">
                <canvas
                    id="firmaPacienteCanvas"
                    class="firma-canvas"
                    width="600"
                    height="200">
                </canvas>
            </div>

            <input
                type="hidden"
                name="firma_paciente"
                id="firmaPaciente">

            <button
                type="button"
                class="btn-limpiar-firma"
                onclick="limpiarFirma('paciente')">
                Limpiar firma
            </button>

        </div>

    </div>

</div>

<br>
<br>
<br>
<button type="reset" class="btn-primary">Limpiar</button>
<button type="submit" class="btn-primary">

💾 Guardar y continuar

</button>
<script src="../js/firmas.js"></script>

</form>
