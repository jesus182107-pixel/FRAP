<h1>Bienvenido al Sistema FRAP</h1>

<hr>

<p>Selecciona una opción del menú para comenzar.</p>

<br>

<h3>Resumen</h3>

<ul>
    <li>FRAP registrados</li>
    <li>Pacientes</li>
    <li>Servicios del día</li>
</ul>