<?php

/* =========================================================
   CONEXIÓN
   ========================================================= */
include("../php/conexion.php");


/* =========================================================
   OBTENER ID DEL FRAP
   ========================================================= */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No se recibió el ID del FRAP.");
}

$id = intval($_GET['id']);


/* =========================================================
   CONSULTAR FRAP
   ========================================================= */
$sql = "SELECT * FROM frap WHERE id = $id";
$resultado = mysqli_query($conn, $sql);

if (!$resultado) {
    die("Error en la consulta: " . mysqli_error($conn));
}

if (mysqli_num_rows($resultado) == 0) {
    die("No se encontró el FRAP.");
}

$frap = mysqli_fetch_assoc($resultado);

// Función para mostrar valores de forma segura
function mostrar($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

// Función para marcar selected en options
function seleccionado($valor_db, $valor_opcion) {
    return ($valor_db === $valor_opcion) ? 'selected' : '';
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar FRAP</title>
    <link rel="stylesheet" href="../css/editar.css">
</head>
<body>

    <form class="frap-form" action="../php/actualizar_frap.php" method="POST">

        <!-- ID OCULTO -->
        <input type="hidden" name="id" value="<?php echo $frap['id']; ?>">

        <div class="form-grid">

            <!-- ENCABEZADO -->
            <div class="form-group col-12">
                <h3>✏️ Editar FRAP</h3>
            </div>

            <!-- DATOS DEL FRAP -->
            <div class="form-group col-4">
                <label>Folio</label>
                <input type="text" name="folio" value="<?php echo mostrar($frap['folio']); ?>" readonly>
            </div>

            <div class="form-group col-4">
                <label>Fecha</label>
                <input type="date" name="fecha" value="<?php echo mostrar($frap['fecha']); ?>" required>
            </div>

            <div class="form-group col-4">
                <label>Hora</label>
                <input type="time" name="hora" value="<?php echo mostrar($frap['hora']); ?>">
            </div>

            <!-- SEDE -->
            <div class="form-group col-4">
                <label>Sede</label>
                <input type="text" name="sede" value="<?php echo mostrar($frap['sede']); ?>">
            </div>

            <!-- UNIDAD -->
            <div class="form-group col-4">
                <label>Unidad</label>
                <select name="unidad">
                    <option value="">Seleccione</option>
                    <?php
                    $unidades = ['A-01', 'A-02', 'A-03', 'A-04'];
                    foreach ($unidades as $u) {
                        $sel = ($frap['unidad'] == $u) ? 'selected' : '';
                        echo "<option value='$u' $sel>$u</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- OPERADOR -->
            <div class="form-group col-4">
                <label>Nombre del Operador</label>
                <input type="text" name="nombre_operador" value="<?php echo mostrar($frap['nombre_operador']); ?>">
            </div>

            <!-- JEFE DE SERVICIO -->
            <div class="form-group col-4">
                <label>Jefe de Servicio</label>
                <input type="text" name="jefe_servicio" value="<?php echo mostrar($frap['jefe_servicio']); ?>">
            </div>

            <!-- AUXILIARES -->
            <div class="form-group col-4">
                <label>Auxiliares</label>
                <input type="text" name="auxilires" value="<?php echo mostrar($frap['auxilires']); ?>">
            </div>

            <!-- TIEMPOS DEL SERVICIO -->
            <div class="form-group col-4">
                <label>Hora de llamada</label>
                <input type="time" name="hora_llamada" value="<?php echo mostrar($frap['hora_llamada']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Salida de Base</label>
                <input type="time" name="salida_base" value="<?php echo mostrar($frap['salida_base']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Llegada al Lugar</label>
                <input type="time" name="llegada_lugar" value="<?php echo mostrar($frap['llegada_lugar']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Inicio de Traslado</label>
                <input type="time" name="inicio_traslado" value="<?php echo mostrar($frap['inicio_traslado']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Llegada al Hospital</label>
                <input type="time" name="llegada_hospital" value="<?php echo mostrar($frap['llegada_hospital']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Salida del Hospital</label>
                <input type="time" name="salida_hospital" value="<?php echo mostrar($frap['salida_hospital']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Llegada a Base</label>
                <input type="time" name="llegada_base" value="<?php echo mostrar($frap['llegada_base']); ?>">
            </div>

            <!-- UBICACIÓN DEL SERVICIO -->
            <div class="form-group col-8">
                <label>Dirección del Servicio</label>
                <textarea name="direccion_servicio"><?php echo mostrar($frap['direccion_servicio']); ?></textarea>
            </div>

            <div class="form-group col-4">
                <label>Municipio</label>
                <input type="text" name="municipio" value="<?php echo mostrar($frap['municipio']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Estado</label>
                <input type="text" name="estado" value="<?php echo mostrar($frap['estado']); ?>">
            </div>

            <!-- DATOS DEL PACIENTE -->
            <div class="form-group col-8">
                <label>Nombre del Paciente</label>
                <input type="text" name="nombre_paciente" value="<?php echo mostrar($frap['nombre_paciente']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Número de Teléfono</label>
                <input type="text" name="numero_telefono" value="<?php echo mostrar($frap['numero_telefono']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Edad</label>
                <input type="number" name="edad" value="<?php echo mostrar($frap['edad']); ?>">
            </div>

            <!-- SEXO -->
            <div class="form-group col-2">
                <label>Sexo</label>
                <select name="sexo">
                    <option value="">Seleccione</option>
                    <option value="MASCULINO" <?php echo seleccionado($frap['sexo'] ?? '', 'MASCULINO'); ?>>MASCULINO</option>
                    <option value="FEMENINO" <?php echo seleccionado($frap['sexo'] ?? '', 'FEMENINO'); ?>>FEMENINO</option>
                    <option value="OTRO" <?php echo seleccionado($frap['sexo'] ?? '', 'OTRO'); ?>>OTRO</option>
                </select>
            </div>

            <div class="form-group col-8">
                <label>Domicilio</label>
                <textarea name="domicilio"><?php echo mostrar($frap['domicilio']); ?></textarea>
            </div>

            <!-- SERVICIO MÉDICO -->
            <div class="form-group col-4">
                <label>Servicio Médico</label>
                <select name="servicio_medico">
                    <option value="">Seleccione</option>
                    <?php
                    $servicios = ['IMSS', 'ISSSTE', 'INSABI', 'CRUZ ROJA', 'PARTICULAR', 'OTRO'];
                    foreach ($servicios as $s) {
                        $sel = (strtoupper(trim($frap['servicio_medico'] ?? '')) === $s) ? 'selected' : '';
                        echo "<option value='$s' $sel>$s</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- MOTIVO DEL SERVICIO -->
            <div class="form-group col-8">
                <label>Motivo del Servicio</label>
                <select name="selecciona_motivo">
                    <option value="">Seleccione</option>
                    <?php
                    $motivos = [
                        "Accidente Industrial o En Oficina",
                        "Accidente Vehicular",
                        "Alergia/ Picadura De Animal",
                        "Apoyo a Ambulancia Terrestre",
                        "Apoyo En Incendio",
                        "Apoyo En Sismo",
                        "Asfixia/ Ahogamiento",
                        "Complicacion Diabetica",
                        "Complicación Gineco-obstetrica",
                        "Complicacion Respiratoria",
                        "Convulsiones",
                        "Electrocucion",
                        "Evento Vascular Cerebral",
                        "Exposición a Calor/ Frio",
                        "Hemorragia",
                        "Intoxicación",
                        "Lesion Por Arma Blanca",
                        "Lesion Por Arma De Fuego",
                        "Mordedura De Animal",
                        "Atropellado",
                        "Apoyo a Ambulancia Aerea",
                        "Caida",
                        "Cobertura De Evento",
                        "Dolor Intenso",
                        "Dolor Toracico/ Cardiovascular",
                        "Inhalacion De Gases Peligrosos",
                        "Intento/Amenaza De Suicidio",
                        "Parto",
                        "Perdida De La Consciencia",
                        "Persona Enferma",
                        "Problema De La Conducta",
                        "Quemaduras",
                        "Sangrado/ Laceracion",
                        "sincope/ Lipotimia",
                        "Sobredosis De Fármacos",
                        "Traslado Foraneo",
                        "Traslado Local",
                        "Fractura",
                        "Traslado De Terapia Intensiva",
                        "Traslado De Urgencia Avanzada"
                    ];
                    foreach ($motivos as $m) {
                        $sel = (($frap['selecciona_motivo'] ?? '') === $m) ? 'selected' : '';
                        echo "<option value='" . htmlspecialchars($m) . "' $sel>" . htmlspecialchars($m) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- SIGNOS Y SÍNTOMAS -->
            <div class="form-group col-12">
                <label>Signos y Síntomas</label>
                <textarea name="signos_sintomas"><?php echo mostrar($frap['signos_sintomas']); ?></textarea>
            </div>

            <!-- ANTECEDENTES -->
            <div class="form-group col-6">
                <label>Alergias</label>
                <textarea name="alergias"><?php echo mostrar($frap['alergias']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Medicamentos Frecuentes</label>
                <textarea name="medicamentos_frecuentes"><?php echo mostrar($frap['medicamentos_frecuentes']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Enfermedades / Cirugías</label>
                <textarea name="enfermedades_cirugias"><?php echo mostrar($frap['enfermedades_cirugias']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Eventos Previos</label>
                <textarea name="eventos_previos"><?php echo mostrar($frap['eventos_previos']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Última Comida</label>
                <textarea name="ultima_comida"><?php echo mostrar($frap['ultima_comida']); ?></textarea>
            </div>

            <!-- DATOS OBSTÉTRICOS -->
            <div class="form-group col-2">
                <label>Gesta</label>
                <input type="text" name="gesta" value="<?php echo mostrar($frap['gesta']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Aborto</label>
                <input type="text" name="aborto" value="<?php echo mostrar($frap['aborto']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Partos</label>
                <input type="text" name="partos" value="<?php echo mostrar($frap['partos']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Cesáreas</label>
                <input type="text" name="cesarias" value="<?php echo mostrar($frap['cesarias']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Semanas de Gestación</label>
                <input type="text" name="semanas_gestacion" value="<?php echo mostrar($frap['semanas_gestacion']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Fecha de Parto</label>
                <input type="date" name="fecha_parto" value="<?php echo mostrar($frap['fecha_parto']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Contracciones</label>
                <input type="text" name="contracciones" value="<?php echo mostrar($frap['contracciones']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Duración</label>
                <input type="text" name="duracion" value="<?php echo mostrar($frap['duracion']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Frecuencia</label>
                <input type="text" name="frecuencia" value="<?php echo mostrar($frap['frecuencia']); ?>">
            </div>

            <div class="form-group col-6">
                <label>Sangrado Transvaginal</label>
                <input type="text" name="sangrado_trasvaginal" value="<?php echo mostrar($frap['sangrado_trasvaginal']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Lugar de Nacimiento</label>
                <input type="text" name="lugar_nacimiento" value="<?php echo mostrar($frap['lugar_nacimiento']); ?>">
            </div>

            <div class="form-group col-2">
                <label>Hora de Nacimiento</label>
                <input type="time" name="hora_nacimiento" value="<?php echo mostrar($frap['hora_nacimiento']); ?>">
            </div>

            <!-- VALORACIÓN DEL PACIENTE -->
            <div class="form-group col-6">
                <label>Causa de la Urgencia</label>
                <textarea name="causa_urgencia"><?php echo mostrar($frap['causa_urgencia']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Mecanismo de Lesión</label>
                <textarea name="mecanismo_lesion"><?php echo mostrar($frap['mecanismo_lesion']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Otras Lesiones</label>
                <textarea name="otras_lesiones"><?php echo mostrar($frap['otras_lesiones']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Enfermedad</label>
                <textarea name="enfermedad"><?php echo mostrar($frap['enfermedad']); ?></textarea>
            </div>

            <!-- ESTADO DE LA PIEL -->
            <div class="form-group col-4">
                <label>Estado de la Piel</label>
                <select name="estado_piel">
                    <option value="">Seleccione</option>
                    <?php
                    $piel_opciones = ["Normal", "Palida", "Cianotica", "Rubicunda", "Diaforetica"];
                    foreach ($piel_opciones as $op) {
                        $sel = (($frap['estado_piel'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- VÍA AÉREA -->
            <div class="form-group col-4">
                <label>Vía Aérea</label>
                <select name="via_aerea">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Permeable", "Obstruida"] as $op) {
                        $sel = (($frap['via_aerea'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- REFLEJO DE DEGLUCIÓN -->
            <div class="form-group col-4">
                <label>Reflejo de Deglución</label>
                <select name="reflejo_deglucion">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Presente", "Ausente", "Disminuido"] as $op) {
                        $sel = (($frap['reflejo_deglucion'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- HEMITÓRAX -->
            <div class="form-group col-4">
                <label>Hemitórax</label>
                <select name="hemitorax">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Simétrico", "Asimétrico", "Derecho", "Izquierdo"] as $op) {
                        $sel = (($frap['hemitorax'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group col-4">
                <label>Sitio</label>
                <input type="text" name="sitio" value="<?php echo mostrar($frap['sitio']); ?>">
            </div>

            <!-- PULSO -->
            <div class="form-group col-4">
                <label>Pulso</label>
                <select name="pulso">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Normal", "Rapido", "Lento", "Irregular", "Ausente"] as $op) {
                        $sel = (($frap['pulso'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- AUSCULTACIÓN -->
            <div class="form-group col-4">
                <label>Auscultación</label>
                <select name="auscultacion">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Normal", "Estertores", "Sibilancias", "Disminuida", "Ausente"] as $op) {
                        $sel = (($frap['auscultacion'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- RESPIRACIÓN -->
            <div class="form-group col-4">
                <label>Respiración</label>
                <select name="respiracion">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Normal", "Rapida", "Lenta", "Superficial", "Profunda", "Ausente"] as $op) {
                        $sel = (($frap['respiracion'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- NIVEL DE CONCIENCIA -->
            <div class="form-group col-4">
                <label>Nivel de Conciencia</label>
                <select name="nivel_conciencia">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Alerta", "Respuesta verbal", "Respuesta al dolor", "Sin respuesta"] as $op) {
                        $sel = (($frap['nivel_conciencia'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- FRACTURAS -->
            <div class="form-group col-4">
                <label>Fracturas</label>
                <select name="fracturas">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["No", "Si"] as $op) {
                        $sel = (($frap['fracturas'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- HEMORRAGIAS -->
            <div class="form-group col-4">
                <label>Hemorragias</label>
                <select name="hemorragias">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["No", "Si"] as $op) {
                        $sel = (($frap['hemorragias'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- DISTENSIÓN YUGULAR -->
            <div class="form-group col-4">
                <label>Distensión Yugular</label>
                <select name="distension_yugular">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["No", "Si"] as $op) {
                        $sel = (($frap['distension_yugular'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- EDEMA -->
            <div class="form-group col-4">
                <label>Edema</label>
                <select name="edema">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["No", "Si"] as $op) {
                        $sel = (($frap['edema'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- ESGUINCE -->
            <div class="form-group col-4">
                <label>Esguince</label>
                <select name="esginse">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["No", "Si"] as $op) {
                        $sel = (($frap['esginse'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- PUPILAS -->
            <div class="form-group col-4">
                <label>Pupilas</label>
                <select name="pupilas">
                    <option value="">Seleccione</option>
                    <?php
                    foreach (["Isocoricas", "Midriatricas", "Anisocoricas", "Mioticas"] as $op) {
                        $sel = (($frap['pupilas'] ?? '') === $op) ? 'selected' : '';
                        echo "<option value='$op' $sel>$op</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- SIGNOS VITALES 1 -->
            <div class="form-group col-12">
                <h3>Signos Vitales - Registro 1</h3>
            </div>
            <div class="form-group col-2">
                <label>Hora 1</label>
                <input type="time" name="hora1" value="<?php echo mostrar($frap['hora1']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FC 1</label>
                <input type="text" name="fc1" value="<?php echo mostrar($frap['fc1']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FR 1</label>
                <input type="text" name="fr1" value="<?php echo mostrar($frap['fr1']); ?>">
            </div>
            <div class="form-group col-2">
                <label>TA 1</label>
                <input type="text" name="ta1" value="<?php echo mostrar($frap['ta1']); ?>">
            </div>
            <div class="form-group col-2">
                <label>SpO₂ 1</label>
                <input type="text" name="spo21" value="<?php echo mostrar($frap['spo21']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Temp 1</label>
                <input type="text" name="temp1" value="<?php echo mostrar($frap['temp1']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Glucosa 1</label>
                <input type="text" name="gluc1" value="<?php echo mostrar($frap['gluc1']); ?>">
            </div>

            <!-- SIGNOS VITALES 2 -->
            <div class="form-group col-12">
                <h3>Signos Vitales - Registro 2</h3>
            </div>
            <div class="form-group col-2">
                <label>Hora 2</label>
                <input type="time" name="hora2" value="<?php echo mostrar($frap['hora2']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FC 2</label>
                <input type="text" name="fc2" value="<?php echo mostrar($frap['fc2']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FR 2</label>
                <input type="text" name="fr2" value="<?php echo mostrar($frap['fr2']); ?>">
            </div>
            <div class="form-group col-2">
                <label>TA 2</label>
                <input type="text" name="ta2" value="<?php echo mostrar($frap['ta2']); ?>">
            </div>
            <div class="form-group col-2">
                <label>SpO₂ 2</label>
                <input type="text" name="spo22" value="<?php echo mostrar($frap['spo22']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Temp 2</label>
                <input type="text" name="temp2" value="<?php echo mostrar($frap['temp2']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Glucosa 2</label>
                <input type="text" name="gluc2" value="<?php echo mostrar($frap['gluc2']); ?>">
            </div>

            <!-- SIGNOS VITALES 3 -->
            <div class="form-group col-12">
                <h3>Signos Vitales - Registro 3</h3>
            </div>
            <div class="form-group col-2">
                <label>Hora 3</label>
                <input type="time" name="hora3" value="<?php echo mostrar($frap['hora3']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FC 3</label>
                <input type="text" name="fc3" value="<?php echo mostrar($frap['fc3']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FR 3</label>
                <input type="text" name="fr3" value="<?php echo mostrar($frap['fr3']); ?>">
            </div>
            <div class="form-group col-2">
                <label>TA 3</label>
                <input type="text" name="ta3" value="<?php echo mostrar($frap['ta3']); ?>">
            </div>
            <div class="form-group col-2">
                <label>SpO₂ 3</label>
                <input type="text" name="spo23" value="<?php echo mostrar($frap['spo23']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Temp 3</label>
                <input type="text" name="temp3" value="<?php echo mostrar($frap['temp3']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Glucosa 3</label>
                <input type="text" name="gluc3" value="<?php echo mostrar($frap['gluc3']); ?>">
            </div>

            <!-- SIGNOS VITALES 4 -->
            <div class="form-group col-12">
                <h3>Signos Vitales - Registro 4</h3>
            </div>
            <div class="form-group col-2">
                <label>Hora 4</label>
                <input type="time" name="hora4" value="<?php echo mostrar($frap['hora4']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FC 4</label>
                <input type="text" name="fc4" value="<?php echo mostrar($frap['fc4']); ?>">
            </div>
            <div class="form-group col-2">
                <label>FR 4</label>
                <input type="text" name="fr4" value="<?php echo mostrar($frap['fr4']); ?>">
            </div>
            <div class="form-group col-2">
                <label>TA 4</label>
                <input type="text" name="ta4" value="<?php echo mostrar($frap['ta4']); ?>">
            </div>
            <div class="form-group col-2">
                <label>SpO₂ 4</label>
                <input type="text" name="spo24" value="<?php echo mostrar($frap['spo24']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Temp 4</label>
                <input type="text" name="temp4" value="<?php echo mostrar($frap['temp4']); ?>">
            </div>
            <div class="form-group col-2">
                <label>Glucosa 4</label>
                <input type="text" name="gluc4" value="<?php echo mostrar($frap['gluc4']); ?>">
            </div>

            <!-- DESCRIPCIÓN -->
            <div class="form-group col-6">
                <label>Descripción de la Escena</label>
                <textarea name="descripcion_ecena"><?php echo mostrar($frap['descripcion_ecena']); ?></textarea>
            </div>


            <!-- TRATAMIENTO -->
            <div class="form-group col-4">
                <label>Control Cervical</label>
                <input type="text" name="control_cervical" value="<?php echo mostrar($frap['control_cervical']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Asistencia Ventilatoria</label>
                <input type="text" name="asistencia_ventilatoria" value="<?php echo mostrar($frap['asistencia_ventilatoria']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Líquidos Endovenosos</label>
                <input type="text" name="liquidos_endovenosos" value="<?php echo mostrar($frap['liquidos_endovenosos']); ?>">
            </div>

            <div class="form-group col-6">
                <label>Soluciones Administradas</label>
                <textarea name="soluciones_administradas"><?php echo mostrar($frap['soluciones_administradas']); ?></textarea>
            </div>

            <div class="form-group col-6">
                <label>Control de Hemorragias</label>
                <input type="text" name="control_hemorragias" value="<?php echo mostrar($frap['control_hemorragias']); ?>">
            </div>

            <div class="form-group col-6">
                <label>Aspiración de Secreciones</label>
                <input type="text" name="aspiracion_secreciones" value="<?php echo mostrar($frap['aspiracion_secreciones']); ?>">
            </div>

            <div class="form-group col-6">
                <label>Inmovilización / Curaciones</label>
                <input type="text" name="inmovilisacion_curaciones" value="<?php echo mostrar($frap['inmovilisacion_curaciones']); ?>">
            </div>

            <div class="form-group col-4">
                <label>RCP</label>
                <input type="text" name="rcp" value="<?php echo mostrar($frap['rcp']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Terapia Eléctrica</label>
                <input type="text" name="terapia_electrica" value="<?php echo mostrar($frap['terapia_electrica']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Suturas</label>
                <input type="text" name="suturas" value="<?php echo mostrar($frap['suturas']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Oxígeno</label>
                <input type="text" name="oxigeno" value="<?php echo mostrar($frap['oxigeno']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Joules</label>
                <input type="text" name="joules" value="<?php echo mostrar($frap['joules']); ?>">
            </div>

            <!-- TRIAGE Y ENTREGA -->
            <div class="form-group col-4">
                <label>Triage de Llegada</label>
                <input type="text" name="triage_llegada" value="<?php echo mostrar($frap['triage_llegada']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Triage de Entrega</label>
                <input type="text" name="triage_entrega" value="<?php echo mostrar($frap['triage_entrega']); ?>">
            </div>

            <div class="form-group col-4">
                <label>Entrega al Doctor</label>
                <input type="text" name="entrega_dorctor" value="<?php echo mostrar($frap['entrega_dorctor']); ?>">
            </div>

            <!-- BOTONES -->
            <div class="form-buttons">
                <button type="submit" class="btn-primary">💾 Actualizar FRAP</button>
                <button type="button" class="btn-secondary" onclick="history.back()">↩ Cancelar</button>
            </div>

        </div>

    </form>

</body>
</html>