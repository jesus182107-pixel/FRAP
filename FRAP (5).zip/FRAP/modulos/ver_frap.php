<?php

include("php/conexion.php");

$id = intval($_GET['id']);

$sql = "SELECT * FROM frap WHERE id='$id'";
$resultado = mysqli_query($conn, $sql);

if(mysqli_num_rows($resultado)==0){

    echo "<h2>FRAP no encontrado</h2>";
    exit;

}

$fila = mysqli_fetch_assoc($resultado);

?>

<h2>📋 FRAP <?php echo $fila['folio']; ?></h2>

<div class="frap-view">

    <table>

            <tr>
                <th>Folio</th>
                <td><?php echo $fila['folio']; ?></td>
            </tr>

            <tr>
                <th>Fecha</th>
                <td><?php echo $fila['fecha']; ?></td>
            </tr>

            <tr>
                <th>Hora</th>
                <td><?php echo $fila['hora']; ?></td>
            </tr>
            <tr>
                <th>Sede</th>
                <td><?php echo $fila['sede']; ?></td>
            </tr>
            <tr>
                <th>Unidad</th>
                <td><?php echo $fila['unidad']; ?></td>
            </tr>
            <tr>
                <th>Nombre operador</th>
                <td><?php echo $fila['nombre_operador']; ?></td>
            </tr>

            <tr>
                <th>Jefe Servicio</th>
                <td><?php echo $fila['jefe_servicio']; ?></td>
            </tr>

            <tr>
                <th>Auxiliares</th>
                <td><?php echo $fila['auxilires']; ?></td>
            </tr>

            <tr>
                <th>Hora de LLamada</th>
                <td><?php echo $fila['hora_llamada']; ?></td>
            </tr>

            <tr>
                <th>Salida Base</th>
                <td><?php echo $fila['salida_base']; ?></td>
            </tr>

            <tr>
                <th>Llegada al lugar</th>
                <td><?php echo $fila['llegada_lugar']; ?></td>
            </tr>

            <tr>
                <th>Inicio Traslado</th>
                <td><?php echo $fila['inicio_traslado']; ?></td>
            </tr>

            <tr>
                <th>Llegada a Hospital</th>
                <td><?php echo $fila['llegada_hospital']; ?></td>
            </tr>
            <tr>
                <th>Salida de hospital</th>
                <td><?php echo $fila['salida_hospital']; ?></td>
            </tr>
            <tr>
                <th>Llegada a Base</th>
                <td><?php echo $fila['llegada_base']; ?></td>
            </tr>
            <tr>
                <th>Direccion del Servico</th>
                <td><?php echo $fila['direccion_servicio']; ?></td>
            </tr>
            <tr>
                <th>Municipio</th>
                <td><?php echo $fila['municipio']; ?></td>
            </tr>
            <tr>
                <th>Estado</th>
                <td><?php echo $fila['estado']; ?></td>
            </tr>
            <tr>
                <th>Nombre del paciente</th>
                <td><?php echo $fila['nombre_paciente']; ?></td>
            </tr>
            <tr>
                <th>Numero de Telefono</th>
                <td><?php echo $fila['numero_telefono']; ?></td>
            </tr>
            <tr>
                <th>Edad</th>
                <td><?php echo $fila['edad']; ?></td>
            </tr>
            <tr>
                <th>Sexo</th>
                <td><?php echo $fila['sexo']; ?></td>
            </tr>
            <tr>
                <th>Domicilio</th>
                <td><?php echo $fila['domicilio']; ?></td>
            </tr>
            <tr>
                <th>Servicio Medico</th>
                <td><?php echo $fila['servicio_medico']; ?></td>
            </tr>
            <tr>
                <th>Seleciona Motivo</th>
                <td><?php echo $fila['selecciona_motivo']; ?></td>
            </tr>
            <tr>
                <th>Signos y sintomas</th>
                <td><?php echo $fila['signos_sintomas']; ?></td>
            </tr>
            <tr>
                <th>Alergia</th>
                <td><?php echo $fila['alergias']; ?></td>
            </tr>
            <tr>
                <th>Medicamentos Frecuentes</th>
                <td><?php echo $fila['medicamentos_frecuentes']; ?></td>
            </tr>
            <tr>
                <th>Enfermedades y Cirugias</th>
                <td><?php echo $fila['enfermedades_cirugias']; ?></td>
            </tr>
            <tr>
                <th>Eventos previos</th>
                <td><?php echo $fila['eventos_previos']; ?></td>
            </tr>
            <tr>
                <th>Ultima comida</th>
                <td><?php echo $fila['ultima_comida']; ?></td>
            </tr>
            <tr>
                <th>Gesta</th>
                <td><?php echo $fila['gesta']; ?></td>
            </tr>
            <tr>
                <th>Abortos</th>
                <td><?php echo $fila['aborto']; ?></td>
            </tr>
            <tr>
                <th>Partos</th>
                <td><?php echo $fila['partos']; ?></td>
            </tr>
            <tr>
                <th>Cesarias</th>
                <td><?php echo $fila['cesarias']; ?></td>
            </tr>
            <tr>
                <th>Semanas de Gestacion</th>
                <td><?php echo $fila['semanas_gestacion']; ?></td>
            </tr>
            <tr>
                <th>Fechas de parto</th>
                <td><?php echo $fila['fecha_parto']; ?></td>
            </tr>
            <tr>
                <th>Contracciones</th>
                <td><?php echo $fila['contracciones']; ?></td>
            </tr>
            <tr>
                <th>Duracion</th>
                <td><?php echo $fila['duracion']; ?></td>
            </tr>
            <tr>
                <th>Frecuencia</th>
                <td><?php echo $fila['frecuencia']; ?></td>
            </tr>
            <tr>
                <th>Sangrado trasvaginal</th>
                <td><?php echo $fila['sangrado_trasvaginal']; ?></td>
            </tr>
            <tr>
                <th>Lugar de nacimiento</th>
                <td><?php echo $fila['lugar_nacimiento']; ?></td>
            </tr>
            <tr>
                <th>Hora de nacimiento</th>
                <td><?php echo $fila['hora_nacimiento']; ?></td>
            </tr>
            <tr>
                <th>Causa de urgencia</th>
                <td><?php echo $fila['causa_urgencia']; ?></td>
            </tr>
            <tr>
                <th>Mecanismo de lesion</th>
                <td><?php echo $fila['mecanismo_lesion']; ?></td>
            </tr>
            <tr>
                <th>Otras lesiones</th>
                <td><?php echo $fila['otras_lesiones']; ?></td>
            </tr>
            <tr>
                <th>Enfermedad</th>
                <td><?php echo $fila['enfermedad']; ?></td>
            </tr>
            <tr>
                <th>Estado de la piel</th>
                <td><?php echo $fila['estado_piel']; ?></td>
            </tr>
            <tr>
                <th>Via Aerea</th>
                <td><?php echo $fila['via_aerea']; ?></td>
            </tr>
            <tr>
                <th>Reflejo de deglucion</th>
                <td><?php echo $fila['reflejo_deglucion']; ?></td>
            </tr>
            <tr>
                <th>Hemitorax</th>
                <td><?php echo $fila['hemitorax']; ?></td>
            </tr>
            <tr>
                <th>Sitio</th>
                <td><?php echo $fila['sitio']; ?></td>
            </tr>
            <tr>
                <th>Pulso</th>
                <td><?php echo $fila['pulso']; ?></td>
            </tr>
            <tr>
                <th>Auscultacion</th>
                <td><?php echo $fila['auscultacion']; ?></td>
            </tr>
            <tr>
                <th>Respiracion</th>
                <td><?php echo $fila['respiracion']; ?></td>
            </tr>
            <tr>
                <th>Nivel de Conciencia</th>
                <td><?php echo $fila['nivel_conciencia']; ?></td>
            </tr>
            <tr>
                <th>Fracturas</th>
                <td><?php echo $fila['fracturas']; ?></td>
            </tr>
            <tr>
                <th>Hemorragias</th>
                <td><?php echo $fila['hemorragias']; ?></td>
            </tr>
            <tr>
                <th>Distincion yugular</th>
                <td><?php echo $fila['distension_yugular']; ?></td>
            </tr>
            <tr>
                <th>Edema</th>
                <td><?php echo $fila['edema']; ?></td>
            </tr>
            <tr>
                <th>Esginse</th>
                <td><?php echo $fila['esginse']; ?></td>
            </tr>
            <tr>
                <th>Estado de Pupilas</th>
                <td><?php echo $fila['pupilas']; ?></td>
            </tr>

                    <div class="tabla-signos">

                        <table>

                            <thead>

                                <tr>
                                    <th>HORA</th>
                                    <th>FC</th>
                                    <th>FR</th>
                                    <th>T/A</th>
                                    <th>SPO₂</th>
                                    <th>TEMP</th>
                                    <th>GLUC</th>
                                </tr>

                            </thead>

                            <tbody>

                                <tr>

                                    <td><?php echo $fila['hora1']; ?></td>
                                    <td><?php echo $fila['fc1']; ?></td>
                                    <td><?php echo $fila['fr1']; ?></td>
                                    <td><?php echo $fila['ta1']; ?></td>
                                    <td><?php echo $fila['spo21']; ?></td>
                                    <td><?php echo $fila['temp1']; ?></td>
                                    <td><?php echo $fila['gluc1']; ?></td>

                                </tr>

                                <tr>

                                    <td><?php echo $fila['hora2']; ?></td>
                                    <td><?php echo $fila['fc2']; ?></td>
                                    <td><?php echo $fila['fr2']; ?></td>
                                    <td><?php echo $fila['ta2']; ?></td>
                                    <td><?php echo $fila['spo22']; ?></td>
                                    <td><?php echo $fila['temp2']; ?></td>
                                    <td><?php echo $fila['gluc2']; ?></td>

                                </tr>

                                <tr>

                                    <td><?php echo $fila['hora3']; ?></td>
                                    <td><?php echo $fila['fc3']; ?></td>
                                    <td><?php echo $fila['fr3']; ?></td>
                                    <td><?php echo $fila['ta3']; ?></td>
                                    <td><?php echo $fila['spo23']; ?></td>
                                    <td><?php echo $fila['temp3']; ?></td>
                                    <td><?php echo $fila['gluc3']; ?></td>

                                </tr>

                                <tr>

                                    <td><?php echo $fila['hora4']; ?></td>
                                    <td><?php echo $fila['fc4']; ?></td>
                                    <td><?php echo $fila['fr4']; ?></td>
                                    <td><?php echo $fila['ta4']; ?></td>
                                    <td><?php echo $fila['spo24']; ?></td>
                                    <td><?php echo $fila['temp4']; ?></td>
                                    <td><?php echo $fila['gluc4']; ?></td>

                                </tr>

                            </tbody>

                        </table>
                        <table>
                            <tr>
                            <th>Descripcion de la ecena</th>
                            <td><?php echo $fila['descripcion_ecena']; ?></td>
                            </tr>
                            <tr>
                            <th>Control de Cervicales</th>
                            <td><?php echo $fila['control_cervical']; ?></td>
                            </tr>
                            <tr>
                            <th>Asistencia ventilatoria</th>
                            <td><?php echo $fila['asistencia_ventilatoria']; ?></td>
                            </tr>
                            <tr>
                            <th>Liquidos venosos</th>
                            <td><?php echo $fila['liquidos_endovenosos']; ?></td>
                            </tr>
                            <tr>
                            <th>Soluciones Administradas</th>
                            <td><?php echo $fila['soluciones_administradas']; ?></td>
                            </tr>
                            <tr>
                            <th>Control de Hemorragias</th>
                            <td><?php echo $fila['control_hemorragias']; ?></td>
                            </tr>
                            <tr>
                            <th>Aspiracion de Secreciones</th>
                            <td><?php echo $fila['aspiracion_secreciones']; ?></td>
                            </tr>
                            <tr>
                            <th>Inmovilisacion y Curaciones</th>
                            <td><?php echo $fila['inmovilisacion_curaciones']; ?></td>
                            </tr>
                            <tr>
                            <th>RCP</th>
                            <td><?php echo $fila['rcp']; ?></td>
                            </tr>
                            <tr>
                            <th>Terapia Electrica</th>
                            <td><?php echo $fila['terapia_electrica']; ?></td>
                            </tr>
                            <tr>
                            <th>Sutura</th>
                            <td><?php echo $fila['suturas']; ?></td>
                            </tr>
                            <tr>
                            <th>Oxigeno</th>
                            <td><?php echo $fila['oxigeno']; ?></td>
                            </tr>
                            <tr>
                            <th>Joules</th>
                            <td><?php echo $fila['joules']; ?></td>
                            </tr>
                            <tr>
                            <th>Triage al llegar</th>
                            <td><?php echo $fila['triage_llegada']; ?></td>
                            </tr>
                            <tr>
                            <th>Triage al entregar</th>
                            <td><?php echo $fila['triage_entrega']; ?></td>
                            </tr>
                            <tr>
                            <th>Entrega al Doctor</th>
                            <td><?php echo $fila['entrega_dorctor']; ?></td>
                            </tr>
                        </table>
                    </div>
                    

                    
    </table>

</div>

<br>
<br>
<br>
<br>

<a href="dashboard.php?modulo=historial" class="btn-primary">
← Regresar
</a>