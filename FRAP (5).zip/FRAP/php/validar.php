<?php
session_start();
include("conexion.php");

$usuario = $_POST['usuario'];
$password = $_POST['password'];

$sql = "SELECT * FROM usuarios WHERE usuario='$usuario' AND password='$password'";
$resultado = mysqli_query($conn, $sql);

if (mysqli_num_rows($resultado) == 1) {

    $datos = mysqli_fetch_assoc($resultado);

    $_SESSION['id'] = $datos['id'];
    $_SESSION['nombre'] = $datos['nombre'];
    $_SESSION['usuario'] = $datos['usuario'];

    header("Location: ../dashboard.php");

} else {

    echo "<script>
        alert('Usuario o contraseña incorrectos');
        window.location='../index.php';
    </script>";

}
?>