<?php

include("conexion.php");

// Verificar que sea POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Método no permitido.");
}

// Verificar ID
if (!isset($_POST['id']) || empty($_POST['id'])) {
    die("Error: no se recibió el ID del FRAP.");
}

$id = intval($_POST['id']);

// Función para escapar datos
function escapar($dato, $conn) {
    return mysqli_real_escape_string($conn, $dato ?? '');
}

// Recibir y escapar todos los campos
$folio = escapar($_POST['folio'] ?? '', $conn);
$fecha = escapar($_POST['fecha'] ?? '', $conn);
$hora = escapar($_POST['hora'] ?? '', $conn);
$sede = escapar($_POST['sede'] ?? '', $conn);
$unidad = escapar($_POST['unidad'] ?? '', $conn);
$nombre_operador = escapar($_POST['nombre_operador'] ?? '', $conn);
$jefe_servicio = escapar($_POST['jefe_servicio'] ?? '', $conn);
$auxilires = escapar($_POST['auxilires'] ?? '', $conn);
$hora_llamada = escapar($_POST['hora_llamada'] ?? '', $conn);
$salida_base = escapar($_POST['salida_base'] ?? '', $conn);
$llegada_lugar = escapar($_POST['llegada_lugar'] ?? '', $conn);
$inicio_traslado = escapar($_POST['inicio_traslado'] ?? '', $conn);
$llegada_hospital = escapar($_POST['llegada_hospital'] ?? '', $conn);
$salida_hospital = escapar($_POST['salida_hospital'] ?? '', $conn);
$llegada_base = escapar($_POST['llegada_base'] ?? '', $conn);
$direccion_servicio = escapar($_POST['direccion_servicio'] ?? '', $conn);
$municipio = escapar($_POST['municipio'] ?? '', $conn);
$estado = escapar($_POST['estado'] ?? '', $conn);
$nombre_paciente = escapar($_POST['nombre_paciente'] ?? '', $conn);
$numero_telefono = escapar($_POST['numero_telefono'] ?? '', $conn);
$edad = escapar($_POST['edad'] ?? '', $conn);
$sexo = escapar($_POST['sexo'] ?? '', $conn);
$domicilio = escapar($_POST['domicilio'] ?? '', $conn);
$servicio_medico = escapar($_POST['servicio_medico'] ?? '', $conn);
$selecciona_motivo = escapar($_POST['selecciona_motivo'] ?? '', $conn);
$signos_sintomas = escapar($_POST['signos_sintomas'] ?? '', $conn);
$alergias = escapar($_POST['alergias'] ?? '', $conn);
$medicamentos_frecuentes = escapar($_POST['medicamentos_frecuentes'] ?? '', $conn);
$enfermedades_cirugias = escapar($_POST['enfermedades_cirugias'] ?? '', $conn);
$eventos_previos = escapar($_POST['eventos_previos'] ?? '', $conn);
$ultima_comida = escapar($_POST['ultima_comida'] ?? '', $conn);
$gesta = escapar($_POST['gesta'] ?? '', $conn);
$aborto = escapar($_POST['aborto'] ?? '', $conn);
$partos = escapar($_POST['partos'] ?? '', $conn);
$cesarias = escapar($_POST['cesarias'] ?? '', $conn);
$semanas_gestacion = escapar($_POST['semanas_gestacion'] ?? '', $conn);
$fecha_parto = escapar($_POST['fecha_parto'] ?? '', $conn);
$contracciones = escapar($_POST['contracciones'] ?? '', $conn);
$duracion = escapar($_POST['duracion'] ?? '', $conn);
$frecuencia = escapar($_POST['frecuencia'] ?? '', $conn);
$sangrado_trasvaginal = escapar($_POST['sangrado_trasvaginal'] ?? '', $conn);
$lugar_nacimiento = escapar($_POST['lugar_nacimiento'] ?? '', $conn);
$hora_nacimiento = escapar($_POST['hora_nacimiento'] ?? '', $conn);
$causa_urgencia = escapar($_POST['causa_urgencia'] ?? '', $conn);
$mecanismo_lesion = escapar($_POST['mecanismo_lesion'] ?? '', $conn);
$otras_lesiones = escapar($_POST['otras_lesiones'] ?? '', $conn);
$enfermedad = escapar($_POST['enfermedad'] ?? '', $conn);
$estado_piel = escapar($_POST['estado_piel'] ?? '', $conn);
$via_aerea = escapar($_POST['via_aerea'] ?? '', $conn);
$reflejo_deglucion = escapar($_POST['reflejo_deglucion'] ?? '', $conn);
$hemitorax = escapar($_POST['hemitorax'] ?? '', $conn);
$sitio = escapar($_POST['sitio'] ?? '', $conn);
$pulso = escapar($_POST['pulso'] ?? '', $conn);
$auscultacion = escapar($_POST['auscultacion'] ?? '', $conn);
$respiracion = escapar($_POST['respiracion'] ?? '', $conn);
$nivel_conciencia = escapar($_POST['nivel_conciencia'] ?? '', $conn);
$fracturas = escapar($_POST['fracturas'] ?? '', $conn);
$hemorragias = escapar($_POST['hemorragias'] ?? '', $conn);
$distension_yugular = escapar($_POST['distension_yugular'] ?? '', $conn);
$edema = escapar($_POST['edema'] ?? '', $conn);
$esginse = escapar($_POST['esginse'] ?? '', $conn);
$pupilas = escapar($_POST['pupilas'] ?? '', $conn);
$hora1 = escapar($_POST['hora1'] ?? '', $conn);
$fc1 = escapar($_POST['fc1'] ?? '', $conn);
$fr1 = escapar($_POST['fr1'] ?? '', $conn);
$ta1 = escapar($_POST['ta1'] ?? '', $conn);
$spo21 = escapar($_POST['spo21'] ?? '', $conn);
$temp1 = escapar($_POST['temp1'] ?? '', $conn);
$gluc1 = escapar($_POST['gluc1'] ?? '', $conn);
$hora2 = escapar($_POST['hora2'] ?? '', $conn);
$fc2 = escapar($_POST['fc2'] ?? '', $conn);
$fr2 = escapar($_POST['fr2'] ?? '', $conn);
$ta2 = escapar($_POST['ta2'] ?? '', $conn);
$spo22 = escapar($_POST['spo22'] ?? '', $conn);
$temp2 = escapar($_POST['temp2'] ?? '', $conn);
$gluc2 = escapar($_POST['gluc2'] ?? '', $conn);
$hora3 = escapar($_POST['hora3'] ?? '', $conn);
$fc3 = escapar($_POST['fc3'] ?? '', $conn);
$fr3 = escapar($_POST['fr3'] ?? '', $conn);
$ta3 = escapar($_POST['ta3'] ?? '', $conn);
$spo23 = escapar($_POST['spo23'] ?? '', $conn);
$temp3 = escapar($_POST['temp3'] ?? '', $conn);
$gluc3 = escapar($_POST['gluc3'] ?? '', $conn);
$hora4 = escapar($_POST['hora4'] ?? '', $conn);
$fc4 = escapar($_POST['fc4'] ?? '', $conn);
$fr4 = escapar($_POST['fr4'] ?? '', $conn);
$ta4 = escapar($_POST['ta4'] ?? '', $conn);
$spo24 = escapar($_POST['spo24'] ?? '', $conn);
$temp4 = escapar($_POST['temp4'] ?? '', $conn);
$gluc4 = escapar($_POST['gluc4'] ?? '', $conn);
$descripcion_ecena = escapar($_POST['descripcion_ecena'] ?? '', $conn);
// $descripcion = escapar($_POST['descripcion'] ?? '', $conn); // ELIMINADO: no existe en la tabla
$control_cervical = escapar($_POST['control_cervical'] ?? '', $conn);
$asistencia_ventilatoria = escapar($_POST['asistencia_ventilatoria'] ?? '', $conn);
$liquidos_endovenosos = escapar($_POST['liquidos_endovenosos'] ?? '', $conn);
$soluciones_administradas = escapar($_POST['soluciones_administradas'] ?? '', $conn);
$control_hemorragias = escapar($_POST['control_hemorragias'] ?? '', $conn);
$aspiracion_secreciones = escapar($_POST['aspiracion_secreciones'] ?? '', $conn);
$inmovilisacion_curaciones = escapar($_POST['inmovilisacion_curaciones'] ?? '', $conn);
$rcp = escapar($_POST['rcp'] ?? '', $conn);
$terapia_electrica = escapar($_POST['terapia_electrica'] ?? '', $conn);
$suturas = escapar($_POST['suturas'] ?? '', $conn);
$oxigeno = escapar($_POST['oxigeno'] ?? '', $conn);
$joules = escapar($_POST['joules'] ?? '', $conn);
$triage_llegada = escapar($_POST['triage_llegada'] ?? '', $conn);
$triage_entrega = escapar($_POST['triage_entrega'] ?? '', $conn);
$entrega_dorctor = escapar($_POST['entrega_dorctor'] ?? '', $conn);

// Construir consulta SQL (SIN el campo 'descripcion')
$sql = "UPDATE frap SET
    folio = '$folio',
    fecha = '$fecha',
    hora = '$hora',
    sede = '$sede',
    unidad = '$unidad',
    nombre_operador = '$nombre_operador',
    jefe_servicio = '$jefe_servicio',
    auxilires = '$auxilires',
    hora_llamada = '$hora_llamada',
    salida_base = '$salida_base',
    llegada_lugar = '$llegada_lugar',
    inicio_traslado = '$inicio_traslado',
    llegada_hospital = '$llegada_hospital',
    salida_hospital = '$salida_hospital',
    llegada_base = '$llegada_base',
    direccion_servicio = '$direccion_servicio',
    municipio = '$municipio',
    estado = '$estado',
    nombre_paciente = '$nombre_paciente',
    numero_telefono = '$numero_telefono',
    edad = '$edad',
    sexo = '$sexo',
    domicilio = '$domicilio',
    servicio_medico = '$servicio_medico',
    selecciona_motivo = '$selecciona_motivo',
    signos_sintomas = '$signos_sintomas',
    alergias = '$alergias',
    medicamentos_frecuentes = '$medicamentos_frecuentes',
    enfermedades_cirugias = '$enfermedades_cirugias',
    eventos_previos = '$eventos_previos',
    ultima_comida = '$ultima_comida',
    gesta = '$gesta',
    aborto = '$aborto',
    partos = '$partos',
    cesarias = '$cesarias',
    semanas_gestacion = '$semanas_gestacion',
    fecha_parto = '$fecha_parto',
    contracciones = '$contracciones',
    duracion = '$duracion',
    frecuencia = '$frecuencia',
    sangrado_trasvaginal = '$sangrado_trasvaginal',
    lugar_nacimiento = '$lugar_nacimiento',
    hora_nacimiento = '$hora_nacimiento',
    causa_urgencia = '$causa_urgencia',
    mecanismo_lesion = '$mecanismo_lesion',
    otras_lesiones = '$otras_lesiones',
    enfermedad = '$enfermedad',
    estado_piel = '$estado_piel',
    via_aerea = '$via_aerea',
    reflejo_deglucion = '$reflejo_deglucion',
    hemitorax = '$hemitorax',
    sitio = '$sitio',
    pulso = '$pulso',
    auscultacion = '$auscultacion',
    respiracion = '$respiracion',
    nivel_conciencia = '$nivel_conciencia',
    fracturas = '$fracturas',
    hemorragias = '$hemorragias',
    distension_yugular = '$distension_yugular',
    edema = '$edema',
    esginse = '$esginse',
    pupilas = '$pupilas',
    hora1 = '$hora1',
    fc1 = '$fc1',
    fr1 = '$fr1',
    ta1 = '$ta1',
    spo21 = '$spo21',
    temp1 = '$temp1',
    gluc1 = '$gluc1',
    hora2 = '$hora2',
    fc2 = '$fc2',
    fr2 = '$fr2',
    ta2 = '$ta2',
    spo22 = '$spo22',
    temp2 = '$temp2',
    gluc2 = '$gluc2',
    hora3 = '$hora3',
    fc3 = '$fc3',
    fr3 = '$fr3',
    ta3 = '$ta3',
    spo23 = '$spo23',
    temp3 = '$temp3',
    gluc3 = '$gluc3',
    hora4 = '$hora4',
    fc4 = '$fc4',
    fr4 = '$fr4',
    ta4 = '$ta4',
    spo24 = '$spo24',
    temp4 = '$temp4',
    gluc4 = '$gluc4',
    descripcion_ecena = '$descripcion_ecena',
    control_cervical = '$control_cervical',
    asistencia_ventilatoria = '$asistencia_ventilatoria',
    liquidos_endovenosos = '$liquidos_endovenosos',
    soluciones_administradas = '$soluciones_administradas',
    control_hemorragias = '$control_hemorragias',
    aspiracion_secreciones = '$aspiracion_secreciones',
    inmovilisacion_curaciones = '$inmovilisacion_curaciones',
    rcp = '$rcp',
    terapia_electrica = '$terapia_electrica',
    suturas = '$suturas',
    oxigeno = '$oxigeno',
    joules = '$joules',
    triage_llegada = '$triage_llegada',
    triage_entrega = '$triage_entrega',
    entrega_dorctor = '$entrega_dorctor'
WHERE id = $id";

// Ejecutar actualización
if (mysqli_query($conn, $sql)) {
    header("Location: ../dashboard.php?modulo=historial&mensaje=actualizado");
    exit;
} else {
    die("Error al actualizar: " . mysqli_error($conn));
}
?>