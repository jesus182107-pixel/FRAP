<?php

/* =========================================================
   CONEXIÓN
   ========================================================= */
include("conexion.php");


/* =========================================================
   VERIFICAR QUE SE RECIBIÓ EL ID
   ========================================================= */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No se recibió el ID del FRAP a eliminar.");
}

$id = intval($_GET['id']);


/* =========================================================
   ELIMINAR EL FRAP
   ========================================================= */
$sql = "DELETE FROM frap WHERE id = $id";

if (mysqli_query($conn, $sql)) {
    
    // Verificar si realmente se eliminó algo
    if (mysqli_affected_rows($conn) > 0) {
        // Redirigir al historial con mensaje de éxito
        header("Location: ../dashboard.php?modulo=historial&mensaje=eliminado");
        exit;
    } else {
        die("No se encontró ningún FRAP con ese ID.");
    }
    
} else {
    die("Error al eliminar el FRAP: " . mysqli_error($conn));
}

?>