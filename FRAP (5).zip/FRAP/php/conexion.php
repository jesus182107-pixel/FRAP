<?php

$host = "localhost";
$usuario = "root";
$password = "";
$database = "frap_db";

$conn = new mysqli($host, $usuario, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

?>