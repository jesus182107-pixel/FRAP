<?php
session_start();
include("conexion.php");

// Verificar que el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    die("Acceso no permitido.");
}

// Recibir datos
$folio = $_POST['folio'] ?? '';
$fecha = $_POST['fecha'] ?? '';
$hora = $_POST['hora'] ?? '';
$sede = $_POST['sede'] ?? '';
$unidad = $_POST['unidad'] ?? '';
$nombre_operador = $_POST['nombre_operador'] ?? '';
$jefe_servicio = $_POST['jefe_servicio'] ?? '';
$auxilires = $_POST['auxilires'] ?? '';

$hora_llamada = $_POST['hora_llamada'] ?? '';
$salida_base = $_POST['salida_base'] ?? '';
$llegada_lugar = $_POST['llegada_lugar'] ?? '';
$inicio_traslado = $_POST['inicio_traslado'] ?? '';
$llegada_hospital = $_POST['llegada_hospital'] ?? '';
$salida_hospital = $_POST['salida_hospital'] ?? '';
$llegada_base = $_POST['llegada_base'] ?? '';

$direccion_servicio = $_POST['direccion_servicio'] ?? '';
$municipio = $_POST['municipio'] ?? '';
$estado = $_POST['estado'] ?? '';

$nombre_paciente = $_POST['nombre_paciente'] ?? '';
$numero_telefono = $_POST['numero_telefono'] ?? '';
$edad = $_POST['edad'] ?? '';
$sexo = $_POST['sexo'] ?? '';
$domicilio = $_POST['domicilio'] ?? '';

$servicio_medico = $_POST['servicio_medico'] ?? '';
$selecciona_motivo = $_POST['selecciona_motivo'] ?? '';

$signos_sintomas = $_POST['signos_sintomas'] ?? '';
$alergias = $_POST['alergias'] ?? '';
$medicamentos_frecuentes = $_POST['medicamentos_frecuentes'] ?? '';
$enfermedades_cirugias = $_POST['enfermedades_cirugias'] ?? '';
$eventos_previos = $_POST['eventos_previos'] ?? '';
$ultima_comida = $_POST['ultima_comida'] ?? '';

$gesta = $_POST['gesta'] ?? '';
$aborto = $_POST['aborto'] ?? '';
$partos = $_POST['partos'] ?? '';
$cesarias = $_POST['cesarias'] ?? '';
$semanas_gestacion = $_POST['semanas_gestacion'] ?? '';
$fecha_parto = $_POST['fecha_parto'] ?? '';
$contracciones = $_POST['contracciones'] ?? '';
$duracion = $_POST['duracion'] ?? '';
$frecuencia = $_POST['frecuencia'] ?? '';
$sangrado_trasvaginal = $_POST['sangrado_trasvaginal'] ?? '';

$lugar_nacimiento = $_POST['lugar_nacimiento'] ?? '';
$hora_nacimiento = $_POST['hora_nacimiento'] ?? '';

$causa_urgencia = $_POST['causa_urgencia'] ?? '';
$mecanismo_lesion = $_POST['mecanismo_lesion'] ?? '';
$otras_lesiones = $_POST['otras_lesiones'] ?? '';
$enfermedad = $_POST['enfermedad'] ?? '';

$estado_piel = $_POST['estado_piel'] ?? '';
$via_aerea = $_POST['via_aerea'] ?? '';
$reflejo_deglucion = $_POST['reflejo_deglucion'] ?? '';
$hemitorax = $_POST['hemitorax'] ?? '';
$sitio = $_POST['sitio'] ?? '';
$pulso = $_POST['pulso'] ?? '';
$auscultacion = $_POST['auscultacion'] ?? '';
$respiracion = $_POST['respiracion'] ?? '';
$nivel_conciencia = $_POST['nivel_conciencia'] ?? '';
$fracturas = $_POST['fracturas'] ?? '';
$hemorragias = $_POST['hemorragias'] ?? '';
$distension_yugular = $_POST['distension_yugular'] ?? '';
$edema = $_POST['edema'] ?? '';
$esginse = $_POST['esginse'] ?? '';
$pupilas = $_POST['pupilas'] ?? '';
/*==============================
SIGNOS VITALES
==============================*/

$hora1 = $_POST['hora1'] ?? '';
$fc1 = $_POST['fc1'] ?? '';
$fr1 = $_POST['fr1'] ?? '';
$ta1 = $_POST['ta1'] ?? '';
$spo21 = $_POST['spo21'] ?? '';
$temp1 = $_POST['temp1'] ?? '';
$gluc1 = $_POST['gluc1'] ?? '';

$hora2 = $_POST['hora2'] ?? '';
$fc2 = $_POST['fc2'] ?? '';
$fr2 = $_POST['fr2'] ?? '';
$ta2 = $_POST['ta2'] ?? '';
$spo22 = $_POST['spo22'] ?? '';
$temp2 = $_POST['temp2'] ?? '';
$gluc2 = $_POST['gluc2'] ?? '';

$hora3 = $_POST['hora3'] ?? '';
$fc3 = $_POST['fc3'] ?? '';
$fr3 = $_POST['fr3'] ?? '';
$ta3 = $_POST['ta3'] ?? '';
$spo23 = $_POST['spo23'] ?? '';
$temp3 = $_POST['temp3'] ?? '';
$gluc3 = $_POST['gluc3'] ?? '';

$hora4 = $_POST['hora4'] ?? '';
$fc4 = $_POST['fc4'] ?? '';
$fr4 = $_POST['fr4'] ?? '';
$ta4 = $_POST['ta4'] ?? '';
$spo24 = $_POST['spo24'] ?? '';
$temp4 = $_POST['temp4'] ?? '';
$gluc4 = $_POST['gluc4'] ?? '';

/*==============================
TRATAMIENTO
==============================*/

$descripcion_ecena = $_POST['descripcion_ecena'] ?? '';


$control_cervical = $_POST['control_cervical'] ?? '';
$asistencia_ventilatoria = $_POST['asistencia_ventilatoria'] ?? '';
$liquidos_endovenosos = $_POST['liquidos_endovenosos'] ?? '';
$soluciones_administradas = $_POST['soluciones_administradas'] ?? '';
$control_hemorragias = $_POST['control_hemorragias'] ?? '';
$aspiracion_secreciones = $_POST['aspiracion_secreciones'] ?? '';
$inmovilisacion_curaciones = $_POST['inmovilisacion_curaciones'] ?? '';
$rcp = $_POST['rcp'] ?? '';
$terapia_electrica = $_POST['terapia_electrica'] ?? '';
$suturas = $_POST['suturas'] ?? '';
$oxigeno = $_POST['oxigeno'] ?? '';
$joules = $_POST['joules'] ?? '';

$triage_llegada = $_POST['triage_llegada'] ?? '';
$triage_entrega = $_POST['triage_entrega'] ?? '';
$entrega_dorctor = $_POST['entrega_dorctor'] ?? '';

/*==============================
GENERAR FOLIO AUTOMÁTICO
==============================*/

$anio = date("Y");

$sqlFolio = "SELECT MAX(id) AS ultimo FROM frap";
$resFolio = mysqli_query($conn, $sqlFolio);

if($resFolio){

    $fila = mysqli_fetch_assoc($resFolio);

    $numero = $fila['ultimo'] + 1;

}else{

    $numero = 1;

}

$folio = "FRAP-" . $anio . "-" . str_pad($numero,6,"0",STR_PAD_LEFT);


// Guardar en la tabla frap
$sql = "INSERT INTO frap
(
    
folio,
fecha,
hora,
sede,
unidad,
nombre_operador,
jefe_servicio,
auxilires,
hora_llamada,
salida_base,
llegada_lugar,
inicio_traslado,
llegada_hospital,
salida_hospital,
llegada_base,
direccion_servicio,
municipio,
estado,
nombre_paciente,
numero_telefono,
edad,
sexo,
domicilio,
servicio_medico,
selecciona_motivo,
signos_sintomas,
alergias,
medicamentos_frecuentes,
enfermedades_cirugias,
eventos_previos,
ultima_comida,
gesta,
aborto,
partos,
cesarias,
semanas_gestacion,
fecha_parto,
contracciones,
duracion,
frecuencia,
sangrado_trasvaginal,
lugar_nacimiento,
hora_nacimiento,
causa_urgencia,
mecanismo_lesion,
otras_lesiones,
enfermedad,
estado_piel,
via_aerea,
reflejo_deglucion,
hemitorax,
sitio,
pulso,
auscultacion,
respiracion,
nivel_conciencia,
fracturas,
hemorragias,
distension_yugular,
edema,
esginse,
pupilas,
hora1,
fc1,
fr1,
ta1,
spo21,
temp1,
gluc1,
hora2,
fc2,
fr2,
ta2,
spo22,
temp2,
gluc2,
hora3,
fc3,
fr3,
ta3,
spo23,
temp3,
gluc3,
hora4,
fc4,
fr4,
ta4,
spo24,
temp4,
gluc4,
descripcion_ecena,
control_cervical,
asistencia_ventilatoria,
liquidos_endovenosos,
soluciones_administradas,
control_hemorragias,
aspiracion_secreciones,
inmovilisacion_curaciones,
rcp,
terapia_electrica,
suturas,
oxigeno,
joules,
triage_llegada,
triage_entrega,
entrega_dorctor

)
VALUES
(
    '$folio',
'$fecha',
'$hora',
'$sede',
'$unidad',
'$nombre_operador',
'$jefe_servicio',
'$auxilires',

'$hora_llamada',
'$salida_base',
'$llegada_lugar',
'$inicio_traslado',
'$llegada_hospital',
'$salida_hospital',
'$llegada_base',

'$direccion_servicio',
'$municipio',
'$estado',

'$nombre_paciente',
'$numero_telefono',
'$edad',
'$sexo',
'$domicilio',

'$servicio_medico',
'$selecciona_motivo',

'$signos_sintomas',
'$alergias',
'$medicamentos_frecuentes',
'$enfermedades_cirugias',
'$eventos_previos',
'$ultima_comida',

'$gesta',
'$aborto',
'$partos',
'$cesarias',
'$semanas_gestacion',
'$fecha_parto',
'$contracciones',
'$duracion',
'$frecuencia',
'$sangrado_trasvaginal',
'$lugar_nacimiento',
'$hora_nacimiento',

'$causa_urgencia',
'$mecanismo_lesion',
'$otras_lesiones',
'$enfermedad',

'$estado_piel',
'$via_aerea',
'$reflejo_deglucion',
'$hemitorax',
'$sitio',
'$pulso',
'$auscultacion',
'$respiracion',
'$nivel_conciencia',
'$fracturas',
'$hemorragias',
'$distension_yugular',
'$edema',
'$esginse',
'$pupilas',

'$hora1',
'$fc1',
'$fr1',
'$ta1',
'$spo21',
'$temp1',
'$gluc1',

'$hora2',
'$fc2',
'$fr2',
'$ta2',
'$spo22',
'$temp2',
'$gluc2',

'$hora3',
'$fc3',
'$fr3',
'$ta3',
'$spo23',
'$temp3',
'$gluc3',

'$hora4',
'$fc4',
'$fr4',
'$ta4',
'$spo24',
'$temp4',
'$gluc4',

'$descripcion_ecena',


'$control_cervical',
'$asistencia_ventilatoria',
'$liquidos_endovenosos',
'$soluciones_administradas',
'$control_hemorragias',
'$aspiracion_secreciones',
'$inmovilisacion_curaciones',
'$rcp',
'$terapia_electrica',
'$suturas',
'$oxigeno',
'$joules',

'$triage_llegada',
'$triage_entrega',
'$entrega_dorctor'
)";

if(mysqli_query($conn, $sql)){

    echo "<script>
        alert('FRAP guardado correctamente');
        window.location='../dashboard.php';
    </script>";

}else{

    echo "Error al guardar: " . mysqli_error($conn);

}

mysqli_close($conn);
?>