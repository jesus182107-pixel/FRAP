/* =========================================================
   SISTEMA DE FIRMAS FRAP
   Mouse + Touch + Lápiz
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    crearFirma(
        "firmaOperadorCanvas",
        "firmaOperador"
    );

    crearFirma(
        "firmaPacienteCanvas",
        "firmaPaciente"
    );

});


function crearFirma(canvasId, inputId) {

    const canvas = document.getElementById(canvasId);
    const input = document.getElementById(inputId);

    if (!canvas || !input) {
        return;
    }

    const ctx = canvas.getContext("2d");

    let dibujando = false;

    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";


    /* =====================================================
       OBTENER POSICIÓN DEL PUNTERO
       ===================================================== */

    function obtenerPosicion(evento) {

        const rect = canvas.getBoundingClientRect();

        const escalaX = canvas.width / rect.width;
        const escalaY = canvas.height / rect.height;

        return {
            x: (evento.clientX - rect.left) * escalaX,
            y: (evento.clientY - rect.top) * escalaY
        };
    }


    /* =====================================================
       INICIAR FIRMA
       ===================================================== */

    function iniciarFirma(evento) {

        evento.preventDefault();

        dibujando = true;

        const posicion = obtenerPosicion(evento);

        ctx.beginPath();

        ctx.moveTo(
            posicion.x,
            posicion.y
        );
    }


    /* =====================================================
       DIBUJAR
       ===================================================== */

    function dibujar(evento) {

        if (!dibujando) {
            return;
        }

        evento.preventDefault();

        const posicion = obtenerPosicion(evento);

        ctx.lineTo(
            posicion.x,
            posicion.y
        );

        ctx.stroke();

        guardarFirma();
    }


    /* =====================================================
       TERMINAR FIRMA
       ===================================================== */

    function terminarFirma(evento) {

        if (!dibujando) {
            return;
        }

        evento.preventDefault();

        dibujando = false;

        guardarFirma();
    }


    /* =====================================================
       GUARDAR FIRMA EN INPUT HIDDEN
       ===================================================== */

    function guardarFirma() {

        input.value = canvas.toDataURL("image/png");
    }


    /* =====================================================
       MOUSE
       ===================================================== */

    canvas.addEventListener(
        "pointerdown",
        iniciarFirma
    );

    canvas.addEventListener(
        "pointermove",
        dibujar
    );

    canvas.addEventListener(
        "pointerup",
        terminarFirma
    );

    canvas.addEventListener(
        "pointercancel",
        terminarFirma
    );

    canvas.addEventListener(
        "pointerleave",
        terminarFirma
    );


    /* =====================================================
       EVITAR MENÚ DEL BOTÓN DERECHO
       ===================================================== */

    canvas.addEventListener(
        "contextmenu",
        function (evento) {

            evento.preventDefault();

        }
    );

}


/* =========================================================
   LIMPIAR FIRMA
   ========================================================= */

function limpiarFirma(tipo) {

    let canvas;
    let input;

    if (tipo === "operador") {

        canvas = document.getElementById(
            "firmaOperadorCanvas"
        );

        input = document.getElementById(
            "firmaOperador"
        );

    }

    if (tipo === "paciente") {

        canvas = document.getElementById(
            "firmaPacienteCanvas"
        );

        input = document.getElementById(
            "firmaPaciente"
        );

    }

    if (!canvas || !input) {
        return;
    }

    const ctx = canvas.getContext("2d");

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    input.value = "";
}